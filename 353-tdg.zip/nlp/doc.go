/* Package nlp provides simple natural language processing utilities for Go
...
*/
package nlp
