package stemmer

import (
	"testing"
)

func TestStemmer(t *testing.T) {

}
