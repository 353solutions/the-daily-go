# nlp Project

Provide NLP utilities for Go

Contact: miki@353solutions.com


## Hacking

### Running the Tests

    make test
